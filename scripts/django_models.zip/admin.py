from django.contrib import admin

from .models import (
    AgentComment,
    AgentReport,
    Ammenity,
    Attachment,
    ClientReport,
    Contact,
    ContentCategory,
    ContentItem,
    Contract,
    DocumentTemplate,
    Feature,
    FeaturedLocation,
    FormLead,
    Label,
    Lifestyle,
    Location,
    Neighborhood,
    NewFeature,
    Note,
    Owner,
    Page,
    PageSetting,
    Post,
    PostCategory,
    Probability,
    Property,
    PropertyClassification,
    PropertyLocation,
    PropertyType,
    RequestForProperty,
    SearchLog,
    SocialForm,
    StatLog,
    StatusUpdate,
    TypeOfContact,
    User,
)

@admin.register(AgentComment)
class AgentCommentAdmin(admin.ModelAdmin):
    pass

@admin.register(AgentReport)
class AgentReportAdmin(admin.ModelAdmin):
    pass

@admin.register(Ammenity)
class AmmenityAdmin(admin.ModelAdmin):
    pass

@admin.register(Attachment)
class AttachmentAdmin(admin.ModelAdmin):
    pass

@admin.register(ClientReport)
class ClientReportAdmin(admin.ModelAdmin):
    pass

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    pass

@admin.register(ContentCategory)
class ContentCategoryAdmin(admin.ModelAdmin):
    pass

@admin.register(ContentItem)
class ContentItemAdmin(admin.ModelAdmin):
    pass

@admin.register(Contract)
class ContractAdmin(admin.ModelAdmin):
    pass

@admin.register(DocumentTemplate)
class DocumentTemplateAdmin(admin.ModelAdmin):
    pass

@admin.register(Feature)
class FeatureAdmin(admin.ModelAdmin):
    pass

@admin.register(FeaturedLocation)
class FeaturedLocationAdmin(admin.ModelAdmin):
    pass

@admin.register(FormLead)
class FormLeadAdmin(admin.ModelAdmin):
    pass

@admin.register(Label)
class LabelAdmin(admin.ModelAdmin):
    pass

@admin.register(Lifestyle)
class LifestyleAdmin(admin.ModelAdmin):
    pass

@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    pass

@admin.register(Neighborhood)
class NeighborhoodAdmin(admin.ModelAdmin):
    pass

@admin.register(NewFeature)
class NewFeatureAdmin(admin.ModelAdmin):
    pass

@admin.register(Note)
class NoteAdmin(admin.ModelAdmin):
    pass

@admin.register(Owner)
class OwnerAdmin(admin.ModelAdmin):
    pass

@admin.register(Page)
class PageAdmin(admin.ModelAdmin):
    pass

@admin.register(PageSetting)
class PageSettingAdmin(admin.ModelAdmin):
    pass

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    pass

@admin.register(PostCategory)
class PostCategoryAdmin(admin.ModelAdmin):
    pass

@admin.register(Probability)
class ProbabilityAdmin(admin.ModelAdmin):
    pass

@admin.register(Property)
class PropertyAdmin(admin.ModelAdmin):
    pass

@admin.register(PropertyClassification)
class PropertyClassificationAdmin(admin.ModelAdmin):
    pass

@admin.register(PropertyLocation)
class PropertyLocationAdmin(admin.ModelAdmin):
    pass

@admin.register(PropertyType)
class PropertyTypeAdmin(admin.ModelAdmin):
    pass

@admin.register(RequestForProperty)
class RequestForPropertyAdmin(admin.ModelAdmin):
    pass

@admin.register(SearchLog)
class SearchLogAdmin(admin.ModelAdmin):
    pass

@admin.register(SocialForm)
class SocialFormAdmin(admin.ModelAdmin):
    pass

@admin.register(StatLog)
class StatLogAdmin(admin.ModelAdmin):
    pass

@admin.register(StatusUpdate)
class StatusUpdateAdmin(admin.ModelAdmin):
    pass

@admin.register(TypeOfContact)
class TypeOfContactAdmin(admin.ModelAdmin):
    pass

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    pass
