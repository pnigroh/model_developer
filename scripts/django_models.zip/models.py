"""
Django models auto-generated from CSV export.
Review ForeignKey on_delete policies, blank/null constraints,
and ManyToMany through tables before using in production.
"""

from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey

class AgentComment(models.Model):
    """Auto-generated model for "Agent Comment"."""

    agent = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    attachment = models.FileField(upload_to='uploads/', blank=True, null=True)
    comment = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=255, blank=True, null=True)

    rating = models.IntegerField(blank=True, null=True)
    internal_notes = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = 'Agent Comment'
        verbose_name_plural = 'Agent Comments'

    def __str__(self):
        return str(self.pk)

class AgentReport(models.Model):
    """Auto-generated model for "Agent Report"."""

    agent = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    client = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    comment = models.TextField(blank=True, null=True)
    date_of_creation = models.DateTimeField(blank=True, null=True)
    date_of_visit = models.DateField(blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    motive = models.TextField(blank=True, null=True)
    note = models.CharField(max_length=255, blank=True, null=True)
    owner = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    probability = models.ForeignKey('Probability', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    property = models.ForeignKey('Property', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    property_id_raw = models.CharField(max_length=255, blank=True, null=True)
    report_sent = models.BooleanField(default=False)
    x_type = models.CharField(max_length=255, blank=True, null=True)
    type_of_report = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Agent Report'
        verbose_name_plural = 'Agent Reports'

    def __str__(self):
        return str(self.pk)

class Ammenity(models.Model):
    """Auto-generated model for "Ammenity"."""

    category = models.CharField(max_length=255, blank=True, null=True)
    description_english = models.CharField(max_length=255, blank=True, null=True)
    description_spanish = models.CharField(max_length=255, blank=True, null=True)
    icon = models.ImageField(upload_to='images/', blank=True, null=True)
    position = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)

    class Meta:
        verbose_name = 'Ammenity'
        verbose_name_plural = 'Ammenities'

    def __str__(self):
        return str(self.pk)

class Attachment(models.Model):
    """Auto-generated model for "Attachment"."""

    x_class_ct = models.ForeignKey('contenttypes.ContentType', on_delete=models.SET_NULL, null=True, blank=True, related_name='+')
    x_class_oid = models.PositiveIntegerField(null=True, blank=True)
    x_class = GenericForeignKey('x_class_ct', 'x_class_oid')
    file = models.FileField(upload_to='uploads/', blank=True, null=True)
    x_object_ct = models.ForeignKey('contenttypes.ContentType', on_delete=models.SET_NULL, null=True, blank=True, related_name='+')
    x_object_oid = models.PositiveIntegerField(null=True, blank=True)
    x_object = GenericForeignKey('x_object_ct', 'x_object_oid')
    position = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    published = models.BooleanField(default=False)
    title = models.CharField(max_length=255, blank=True, null=True)
    x_type = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Attachment'
        verbose_name_plural = 'Attachments'

    def __str__(self):
        return str(self.title)

class ClientReport(models.Model):
    """Auto-generated model for "Client Report"."""

    client_name = models.CharField(max_length=255, blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    notified = models.BooleanField(default=False)
    profile = models.TextField(blank=True, null=True)
    property = models.ForeignKey('Property', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    questions_and_special_requirements = models.TextField(blank=True, null=True)
    specific_interest = models.TextField(blank=True, null=True)
    user = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')

    class Meta:
        verbose_name = 'Client Report'
        verbose_name_plural = 'Client Reports'

    def __str__(self):
        return str(self.pk)

class Contact(models.Model):
    """Auto-generated model for "Contact"."""

    attachment = models.FileField(upload_to='uploads/', blank=True, null=True)
    client_notified = models.BooleanField(default=False)
    company = models.CharField(max_length=255, blank=True, null=True)
    date = models.DateTimeField(blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    x_for = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    full_name = models.CharField(max_length=255, blank=True, null=True)
    last_name = models.CharField(max_length=255, blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    phone = models.CharField(max_length=255, blank=True, null=True)
    property = models.ForeignKey('Property', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    recipient = models.CharField(max_length=255, blank=True, null=True)
    status = models.CharField(max_length=255, blank=True, null=True)
    subject = models.CharField(max_length=255, blank=True, null=True)
    type_of_communication = models.ForeignKey('TypeOfContact', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')

    class Meta:
        verbose_name = 'Contact'
        verbose_name_plural = 'Contacts'

    def __str__(self):
        return str(self.full_name)

class ContentCategory(models.Model):
    """Auto-generated model for "Content Category"."""

    description = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    parent = models.ForeignKey('ContentCategory', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')

    class Meta:
        verbose_name = 'Content Category'
        verbose_name_plural = 'Content Categories'

    def __str__(self):
        return str(self.name)

class ContentItem(models.Model):
    """Auto-generated model for "Content Item"."""

    author = models.CharField(max_length=255, blank=True, null=True)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    meta_keywords = models.CharField(max_length=255, blank=True, null=True)
    published = models.BooleanField(default=False)
    short_description = models.CharField(max_length=255, blank=True, null=True)
    short_url = models.CharField(max_length=255, blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Content Item'
        verbose_name_plural = 'Content Items'

    def __str__(self):
        return str(self.title)

class Contract(models.Model):
    """Auto-generated model for "Contract"."""

    agent = models.CharField(max_length=255, blank=True, null=True)
    client = models.CharField(max_length=255, blank=True, null=True)
    final_amount = models.DecimalField(max_digits=14, decimal_places=2, blank=True, null=True)
    last_name = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    owner = models.CharField(max_length=255, blank=True, null=True)
    property = models.CharField(max_length=255, blank=True, null=True)
    signed = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Contract'
        verbose_name_plural = 'Contracts'

    def __str__(self):
        return str(self.name)

class DocumentTemplate(models.Model):
    """Auto-generated model for "Document Template"."""

    content_agent = models.TextField(blank=True, null=True)
    content_customer = models.TextField(blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    initiating_script = models.TextField(blank=True, null=True)
    main_image = models.ImageField(upload_to='images/', blank=True, null=True)
    recipient = models.CharField(max_length=255, blank=True, null=True)
    shortname = models.CharField(max_length=255, blank=True, null=True)
    subject_agent = models.CharField(max_length=255, blank=True, null=True)
    subject_customer = models.CharField(max_length=255, blank=True, null=True)
    surround = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Document Template'
        verbose_name_plural = 'Document Templates'

    def __str__(self):
        return str(self.pk)

class Feature(models.Model):
    """Auto-generated model for "Feature"."""

    description = models.CharField(max_length=255, blank=True, null=True)
    description_es = models.CharField(max_length=255, blank=True, null=True)
    featured_image = models.ImageField(upload_to='images/', blank=True, null=True)
    featured_property = models.ForeignKey('Property', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    image = models.FileField(upload_to='uploads/', blank=True, null=True)
    meta_keywords = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    name_es = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Feature'
        verbose_name_plural = 'Features'

    def __str__(self):
        return str(self.name)

class FeaturedLocation(models.Model):
    """Auto-generated model for "Featured Location"."""

    description = models.CharField(max_length=255, blank=True, null=True)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    locations_covered = models.CharField(max_length=255, blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Featured Location'
        verbose_name_plural = 'Featured Locations'

    def __str__(self):
        return str(self.title)

class FormLead(models.Model):
    """Auto-generated model for "Form Lead"."""

    custom_field_1 = models.CharField(max_length=255, blank=True, null=True)
    custom_field_2 = models.CharField(max_length=255, blank=True, null=True)
    email = models.CharField(max_length=255, blank=True, null=True)
    home_city = models.CharField(max_length=255, blank=True, null=True)
    investing = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    relocating = models.CharField(max_length=255, blank=True, null=True)
    tel = models.CharField(max_length=255, blank=True, null=True)
    timeframe = models.CharField(max_length=255, blank=True, null=True)
    visited_before = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Form Lead'
        verbose_name_plural = 'Form Leads'

    def __str__(self):
        return str(self.name)

class Label(models.Model):
    """Auto-generated model for "Label"."""

    content_en = models.TextField(blank=True, null=True)
    content_es = models.TextField(blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    page = models.ForeignKey('Page', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')

    class Meta:
        verbose_name = 'Label'
        verbose_name_plural = 'Labels'

    def __str__(self):
        return str(self.name)

class Lifestyle(models.Model):
    """Auto-generated model for "Lifestyle"."""

    description = models.CharField(max_length=255, blank=True, null=True)
    description_es = models.CharField(max_length=255, blank=True, null=True)
    image = models.FileField(upload_to='uploads/', blank=True, null=True)
    lifestyle_category = models.CharField(max_length=255, blank=True, null=True)
    meta_keywords = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    name_es = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Lifestyle'
        verbose_name_plural = 'Lifestyles'

    def __str__(self):
        return str(self.name)

class Location(models.Model):
    """Auto-generated model for "Location"."""

    description = models.CharField(max_length=255, blank=True, null=True)
    feature = models.BooleanField(default=False)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    parent = models.ForeignKey('Location', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    position = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)

    class Meta:
        verbose_name = 'Location'
        verbose_name_plural = 'Locations'

    def __str__(self):
        return str(self.name)

class Neighborhood(models.Model):
    """Auto-generated model for "Neighborhood"."""

    image = models.ImageField(upload_to='images/', blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    parent = models.ForeignKey('Neighborhood', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')

    class Meta:
        verbose_name = 'Neighborhood'
        verbose_name_plural = 'Neighborhoods'

    def __str__(self):
        return str(self.name)

class NewFeature(models.Model):
    """Auto-generated model for "New Feature"."""

    description = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    parent = models.CharField(max_length=255, blank=True, null=True)
    position = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)

    class Meta:
        verbose_name = 'New Feature'
        verbose_name_plural = 'New Features'

    def __str__(self):
        return str(self.name)

class Note(models.Model):
    """Auto-generated model for "Note"."""

    x_class_ct = models.ForeignKey('contenttypes.ContentType', on_delete=models.SET_NULL, null=True, blank=True, related_name='+')
    x_class_oid = models.PositiveIntegerField(null=True, blank=True)
    x_class = GenericForeignKey('x_class_ct', 'x_class_oid')
    is_changelog = models.BooleanField(default=False)
    note = models.TextField(blank=True, null=True)
    x_object_ct = models.ForeignKey('contenttypes.ContentType', on_delete=models.SET_NULL, null=True, blank=True, related_name='+')
    x_object_oid = models.PositiveIntegerField(null=True, blank=True)
    x_object = GenericForeignKey('x_object_ct', 'x_object_oid')
    user = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')

    class Meta:
        verbose_name = 'Note'
        verbose_name_plural = 'Notes'

    def __str__(self):
        return str(self.pk)

class Owner(models.Model):
    """Auto-generated model for "Owner"."""

    email = models.CharField(max_length=255, blank=True, null=True)
    language = models.CharField(max_length=255, blank=True, null=True)
    last_name = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    phone = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Owner'
        verbose_name_plural = 'Owners'

    def __str__(self):
        return str(self.name)

class Page(models.Model):
    """Auto-generated model for "Page"."""

    description_en = models.CharField(max_length=255, blank=True, null=True)
    description_es = models.CharField(max_length=255, blank=True, null=True)
    page_title_color = models.CharField(max_length=32, blank=True, null=True)
    show_page_title = models.BooleanField(default=False)
    subtitle_en = models.CharField(max_length=255, blank=True, null=True)
    subtitle_es = models.CharField(max_length=255, blank=True, null=True)
    title_en = models.CharField(max_length=255, blank=True, null=True)
    title_es = models.CharField(max_length=255, blank=True, null=True)
    title_background_image = models.ImageField(upload_to='images/', blank=True, null=True)

    class Meta:
        verbose_name = 'Page'
        verbose_name_plural = 'Pages'

    def __str__(self):
        return str(self.pk)

class PageSetting(models.Model):
    """Auto-generated model for "Page Setting"."""

    address_line_1 = models.CharField(max_length=255, blank=True, null=True)
    address_line_2 = models.CharField(max_length=255, blank=True, null=True)
    address_line_3 = models.CharField(max_length=255, blank=True, null=True)
    contact_email = models.CharField(max_length=255, blank=True, null=True)
    contact_phone_1 = models.CharField(max_length=255, blank=True, null=True)
    contact_phone_2 = models.CharField(max_length=255, blank=True, null=True)
    fax_number = models.CharField(max_length=255, blank=True, null=True)
    home_header = models.IntegerField(blank=True, null=True)
    page_name = models.CharField(max_length=255, blank=True, null=True)
    privacy_policy = models.TextField(blank=True, null=True)
    terms_conditions = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = 'Page Setting'
        verbose_name_plural = 'Page Settings'

    def __str__(self):
        return str(self.pk)

class Post(models.Model):
    """Auto-generated model for "Post"."""

    attachment = models.FileField(upload_to='uploads/', blank=True, null=True)
    category = models.ForeignKey('PostCategory', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    content = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    keywords = models.CharField(max_length=255, blank=True, null=True)
    publication_reference = models.CharField(max_length=255, blank=True, null=True)
    published = models.BooleanField(default=False)
    related_to = models.ManyToManyField('User', blank=True)
    short_description = models.TextField(blank=True, null=True)
    short_name = models.CharField(max_length=255, blank=True, null=True)
    small_image = models.BooleanField(default=False)
    title = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Post'
        verbose_name_plural = 'Posts'

    def __str__(self):
        return str(self.title)

class PostCategory(models.Model):
    """Auto-generated model for "Post Category"."""

    parent = models.CharField(max_length=255, blank=True, null=True)
    title_en = models.CharField(max_length=255, blank=True, null=True)
    title_es = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Post Category'
        verbose_name_plural = 'Post Categories'

    def __str__(self):
        return str(self.pk)

class Probability(models.Model):
    """Auto-generated model for "probability"."""

    description = models.TextField(blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    position = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)

    class Meta:
        verbose_name = 'probability'
        verbose_name_plural = 'probabilities'

    def __str__(self):
        return str(self.name)

class Property(models.Model):
    """Auto-generated model for "Property"."""

    agent = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    agent_contact_count = models.IntegerField(blank=True, null=True)
    allimageurls = models.CharField(max_length=255, blank=True, null=True)
    ammenities = models.ManyToManyField('Ammenity', blank=True)
    bathrooms = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    bedrooms = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    cadastre = models.FileField(upload_to='uploads/', blank=True, null=True)
    cadastre_number = models.IntegerField(blank=True, null=True)
    comments = models.TextField(blank=True, null=True)
    commision_value = models.CharField(max_length=255, blank=True, null=True)
    composite_id = models.CharField(max_length=255, blank=True, null=True)
    condominium_regulation = models.FileField(upload_to='uploads/', blank=True, null=True)
    construction_area = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    contract_type = models.CharField(max_length=255, blank=True, null=True)
    correo_prueba = models.EmailField(blank=True, null=True)
    craiglist = models.CharField(max_length=255, blank=True, null=True)
    customer_agent_contact = models.CharField(max_length=255, blank=True, null=True)
    customer_info_sent = models.CharField(max_length=255, blank=True, null=True)
    date_of_exit = models.DateTimeField(blank=True, null=True)
    date_of_publication = models.DateTimeField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    description_es = models.TextField(blank=True, null=True)
    direct_or_indirect = models.CharField(max_length=255, blank=True, null=True)
    email_request_count = models.IntegerField(blank=True, null=True)
    encuentra_24 = models.CharField(max_length=255, blank=True, null=True)
    exact_address = models.TextField(blank=True, null=True)
    featured = models.BooleanField(default=False)
    features = models.ManyToManyField('Feature', blank=True)
    flooring = models.CharField(max_length=255, blank=True, null=True)
    floors = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    folio_number = models.CharField(max_length=255, blank=True, null=True)
    for_rent = models.BooleanField(default=False)
    for_sale = models.BooleanField(default=False)
    for_vacation_rental = models.BooleanField(default=False)
    garage_size = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    house_number = models.CharField(max_length=255, blank=True, null=True)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    indirect_view_count = models.IntegerField(blank=True, null=True)
    inmotico = models.CharField(max_length=255, blank=True, null=True)
    land_use = models.FileField(upload_to='uploads/', blank=True, null=True)
    latitude = models.CharField(max_length=255, blank=True, null=True)
    lifestyles = models.ManyToManyField('Lifestyle', blank=True)
    links_to_external_platforms = models.TextField(blank=True, null=True)
    links_to_own_platforms = models.TextField(blank=True, null=True)
    longitude = models.CharField(max_length=255, blank=True, null=True)
    lot_area = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    maintenance_quota = models.DecimalField(max_digits=14, decimal_places=2, blank=True, null=True)
    min_price = models.DecimalField(max_digits=14, decimal_places=2, blank=True, null=True)
    neighborhood = models.ManyToManyField('Neighborhood', blank=True)
    new_feature = models.ManyToManyField('NewFeature', blank=True)
    new_property_type = models.ManyToManyField('PropertyClassification', blank=True)
    number_of_images = models.IntegerField(blank=True, null=True)
    observaciones = models.CharField(max_length=255, blank=True, null=True)
    olx = models.CharField(max_length=255, blank=True, null=True)
    owner = models.ForeignKey('Owner', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    parking_spaces = models.IntegerField(blank=True, null=True)
    pdf_file_import = models.CharField(max_length=255, blank=True, null=True)
    pet_friendly = models.BooleanField(default=False)
    position = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    price_per_meter = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    professional_pictures = models.BooleanField(default=False)
    project_name = models.CharField(max_length=255, blank=True, null=True)
    property_label = models.CharField(max_length=255, blank=True, null=True)
    property_location = models.ForeignKey('Location', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    property_location_final = models.ForeignKey('PropertyLocation', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    property_name = models.CharField(max_length=255, blank=True, null=True)
    # NOTE: unknown source type 'Property Status' – defaulted to CharField
    property_status = models.CharField(max_length=255, blank=True, null=True)
    property_sublocation = models.ForeignKey('Location', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    property_type = models.ManyToManyField('PropertyType', blank=True)
    registration_document = models.FileField(upload_to='uploads/', blank=True, null=True)
    rental_price = models.DecimalField(max_digits=14, decimal_places=2, blank=True, null=True)
    roofing = models.CharField(max_length=255, blank=True, null=True)
    service_rooms = models.IntegerField(blank=True, null=True)
    short_video_id = models.CharField(max_length=255, blank=True, null=True)
    show_in_recent = models.BooleanField(default=False)
    social_media = models.CharField(max_length=255, blank=True, null=True)
    square_meters = models.IntegerField(blank=True, null=True)
    storage_area = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    title_es = models.CharField(max_length=255, blank=True, null=True)
    vacation_rental_price = models.DecimalField(max_digits=14, decimal_places=2, blank=True, null=True)
    visit_count = models.IntegerField(blank=True, null=True)
    visit_count_hold = models.IntegerField(blank=True, null=True)
    year_built = models.IntegerField(blank=True, null=True)
    year_of_remodeling = models.IntegerField(blank=True, null=True)
    youtube_url = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = 'Property'
        verbose_name_plural = 'Properties'

    def __str__(self):
        return str(self.title)

class PropertyClassification(models.Model):
    """Auto-generated model for "Property Classification"."""

    description = models.CharField(max_length=255, blank=True, null=True)
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    parent = models.ForeignKey('PropertyClassification', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')

    class Meta:
        verbose_name = 'Property Classification'
        verbose_name_plural = 'Property Classifications'

    def __str__(self):
        return str(self.name)

class PropertyLocation(models.Model):
    """Auto-generated model for "Property Location"."""

    background_image = models.ImageField(upload_to='images/', blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    feature_in_home = models.BooleanField(default=False)
    image_1 = models.ImageField(upload_to='images/', blank=True, null=True)
    image_2 = models.ImageField(upload_to='images/', blank=True, null=True)
    image_3 = models.ImageField(upload_to='images/', blank=True, null=True)
    image_4 = models.ImageField(upload_to='images/', blank=True, null=True)
    image_5 = models.ImageField(upload_to='images/', blank=True, null=True)
    image_6 = models.ImageField(upload_to='images/', blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    parent = models.ForeignKey('PropertyLocation', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    show_gallery = models.BooleanField(default=False)
    video_link = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Property Location'
        verbose_name_plural = 'Property Locations'

    def __str__(self):
        return str(self.name)

class PropertyType(models.Model):
    """Auto-generated model for "Property Type"."""

    name = models.CharField(max_length=255, blank=True, null=True)
    name_es = models.CharField(max_length=255, blank=True, null=True)
    parent = models.ForeignKey('PropertyType', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')

    class Meta:
        verbose_name = 'Property Type'
        verbose_name_plural = 'Property Types'

    def __str__(self):
        return str(self.name)

class RequestForProperty(models.Model):
    """Auto-generated model for "Request For Property"."""

    about_yourself = models.TextField(blank=True, null=True)
    bathrooms = models.CharField(max_length=255, blank=True, null=True)
    bedrooms = models.CharField(max_length=255, blank=True, null=True)
    brief_description = models.TextField(blank=True, null=True)
    budget_range = models.CharField(max_length=255, blank=True, null=True)
    current_location = models.CharField(max_length=255, blank=True, null=True)
    desired = models.TextField(blank=True, null=True)
    email = models.CharField(max_length=255, blank=True, null=True)
    full_name = models.CharField(max_length=255, blank=True, null=True)
    ideal_location = models.CharField(max_length=255, blank=True, null=True)
    must_have = models.TextField(blank=True, null=True)
    parking_spaces = models.CharField(max_length=255, blank=True, null=True)
    phone_number = models.CharField(max_length=255, blank=True, null=True)
    reason_for_moving = models.TextField(blank=True, null=True)
    type_of_property = models.ForeignKey('PropertyType', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')

    class Meta:
        verbose_name = 'Request For Property'
        verbose_name_plural = 'Request For Properties'

    def __str__(self):
        return str(self.full_name)

class SearchLog(models.Model):
    """Auto-generated model for "Search Log"."""

    country_code = models.CharField(max_length=255, blank=True, null=True)
    creation_date = models.DateTimeField(blank=True, null=True)
    ip = models.CharField(max_length=255, blank=True, null=True)
    locations_selected = models.CharField(max_length=255, blank=True, null=True)
    price_range_selected = models.CharField(max_length=255, blank=True, null=True)
    property_types_selected = models.CharField(max_length=255, blank=True, null=True)
    search_criteria = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = 'Search Log'
        verbose_name_plural = 'Search Logs'

    def __str__(self):
        return str(self.pk)

class SocialForm(models.Model):
    """Auto-generated model for "Social Form"."""

    budget_range = models.CharField(max_length=255, blank=True, null=True)
    email = models.CharField(max_length=255, blank=True, null=True)
    last_name = models.CharField(max_length=255, blank=True, null=True)
    location = models.CharField(max_length=255, blank=True, null=True)
    motivation = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    number = models.CharField(max_length=255, blank=True, null=True)
    purchase_time = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Social Form'
        verbose_name_plural = 'Social Forms'

    def __str__(self):
        return str(self.name)

class StatLog(models.Model):
    """Auto-generated model for "Stat Log"."""

    x_class_ct = models.ForeignKey('contenttypes.ContentType', on_delete=models.SET_NULL, null=True, blank=True, related_name='+')
    x_class_oid = models.PositiveIntegerField(null=True, blank=True)
    x_class = GenericForeignKey('x_class_ct', 'x_class_oid')
    custom_stat_1_label = models.CharField(max_length=255, blank=True, null=True)
    custom_stat_1_value = models.IntegerField(blank=True, null=True)
    direct_views = models.IntegerField(blank=True, null=True)
    email_info_request = models.IntegerField(blank=True, null=True)
    email_to_agent = models.IntegerField(blank=True, null=True)
    end_date = models.DateField(blank=True, null=True)
    general_stat = models.BooleanField(default=False)
    indirect_views = models.IntegerField(blank=True, null=True)
    notes = models.IntegerField(blank=True, null=True)
    x_object_ct = models.ForeignKey('contenttypes.ContentType', on_delete=models.SET_NULL, null=True, blank=True, related_name='+')
    x_object_oid = models.PositiveIntegerField(null=True, blank=True)
    x_object = GenericForeignKey('x_object_ct', 'x_object_oid')
    start_date = models.DateField(blank=True, null=True)
    x_type = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Stat Log'
        verbose_name_plural = 'Stat Logs'

    def __str__(self):
        return str(self.pk)

class StatusUpdate(models.Model):
    """Auto-generated model for "Status Update"."""

    agent = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    date = models.DateTimeField(blank=True, null=True)
    property = models.ForeignKey('Property', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    # NOTE: unknown source type 'Property Status' – defaulted to CharField
    status = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Status Update'
        verbose_name_plural = 'Status Updates'

    def __str__(self):
        return str(self.pk)

class TypeOfContact(models.Model):
    """Auto-generated model for "Type Of Contact"."""

    available_to_partner_agents = models.CharField(max_length=255, blank=True, null=True)
    document_template = models.ForeignKey('DocumentTemplate', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    name = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'Type Of Contact'
        verbose_name_plural = 'Type Of Contacts'

    def __str__(self):
        return str(self.name)

class User(models.Model):
    """Auto-generated model for "User"."""

    additional_email = models.CharField(max_length=255, blank=True, null=True)
    agent_assigned = models.ForeignKey('User', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    bio = models.TextField(blank=True, null=True)
    cool_facts = models.TextField(blank=True, null=True)
    facebook = models.CharField(max_length=255, blank=True, null=True)
    full_name = models.CharField(max_length=255, blank=True, null=True)
    home_address = models.CharField(max_length=255, blank=True, null=True)
    home_phone = models.CharField(max_length=255, blank=True, null=True)
    inner_picture = models.ImageField(upload_to='images/', blank=True, null=True)
    instagram_link = models.CharField(max_length=255, blank=True, null=True)
    last_name = models.CharField(max_length=255, blank=True, null=True)
    linkedin = models.CharField(max_length=255, blank=True, null=True)
    login = models.EmailField(blank=True, null=True)
    mobile_phone = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    number_of_listings = models.IntegerField(blank=True, null=True)
    password = models.CharField(max_length=255, blank=True, null=True)
    picture = models.ImageField(upload_to='images/', blank=True, null=True)
    position = models.DecimalField(max_digits=14, decimal_places=4, blank=True, null=True)
    profile = models.TextField(blank=True, null=True)
    request = models.TextField(blank=True, null=True)
    schedule_call_link = models.CharField(max_length=255, blank=True, null=True)
    schedule_visit_link = models.CharField(max_length=255, blank=True, null=True)
    show_on_web = models.BooleanField(default=False)
    specialties = models.CharField(max_length=255, blank=True, null=True)
    square_picture = models.ImageField(upload_to='images/', blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    twitter = models.CharField(max_length=255, blank=True, null=True)
    usergroup = models.CharField(max_length=255, blank=True, null=True)
    website_category = models.CharField(max_length=255, blank=True, null=True)
    wercr_nick = models.CharField(max_length=255, blank=True, null=True)
    whatsapp = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'

    def __str__(self):
        return str(self.full_name)

class LeadScore(models.Model):
    """Auto-generated model for LeadScore."""

    contact = models.ForeignKey('Contact', on_delete=models.SET_NULL, blank=True, null=True, related_name='+')
    score = models.IntegerField(blank=True, null=True)
    scored_at = models.DateTimeField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = 'Lead Score'
        verbose_name_plural = 'Lead Scores'

    def __str__(self):
        return str(self.pk)
